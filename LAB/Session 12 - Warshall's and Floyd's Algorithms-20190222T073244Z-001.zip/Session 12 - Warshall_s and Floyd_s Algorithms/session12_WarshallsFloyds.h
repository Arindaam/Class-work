//Header file for session12_WarshallsFloyds.c

void transitive_closure_warshalls(int **g, int n);

void all_pairs_shortest_path_distances_floyds(int **g, int n);
